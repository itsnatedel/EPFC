<?php
    $prix = 0; //Initialisation du prix qui sera affiché

    //Tableau des différentes offres
    $tabOffres = array(
        'light' => array (
            'prix' => 9.99,
        ),
        'medium' => array (
            'prix' => 12.99,
        ),
        'speed' => array (
            'prix' => 19.99,
        ),
    );
    
    if(isset($_GET['choix'])) {
        $choix = $_GET['choix'];
    }
    
    foreach($tabOffres as $offre => $valueOffre) {
        if ($choix == $offre) {
            foreach($valueOffre as $prix) {
                echo "L'offre " . ucfirst($offre) . " s'&eacute;l&egrave;ve au prix de : " . $prix . " &euro;";
             }
        }
    }
?>