<!DOCTYPE html>
<html>

<head>
    <title>Ex3Presentator</title>
    <meta charset="UTF-8">
</head>

<body>
    <!-- Liens Fruits-Légumes -->
    <a href="ex3selector.php?choix=fruits">Fruits!</a>
    <a href="ex3selector.php?choix=legumes">L&eacute;gumes!</a>

    <?php
    if (isset($_GET['fruit'])) {
        echo "<p>Le fruit choisi est : " . $_GET['fruit'] . "</p>";
    } else if (isset($_GET['legume'])) {
        echo "<p>Le l&eacute;gume choisi est : " . $_GET['legume'] . "</p>";
    }
    ?>

</body>

</html>