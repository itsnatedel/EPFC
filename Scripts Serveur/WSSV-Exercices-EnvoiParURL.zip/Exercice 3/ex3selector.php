<?php

$fruits = array("pomme", "poire", "p&ecirc;che");
$legumes = array("brocoli", "courgette", "poivron");

if (isset($_GET['choix'])) {
    $choix = $_GET['choix'];

    if ($choix == "fruits") {
    ?>  <a href="ex3presentator.php?fruit=Pomme">Pomme</a>
        <a href="ex3presentator.php?fruit=Poire">Poire</a>
        <a href="ex3presentator.php?fruit=P&ecirc;che">P&ecirc;che</a>
    <?php 
    } elseif ($choix == "legumes") {
    ?>  <a href="ex3presentator.php?legume=Brocoli">Brocoli</a>
        <a href="ex3presentator.php?legume=Courgette">Courgette</a>
        <a href="ex3presentator.php?legume=Poivron">Poivron</a>
<?php
    }
}
?>