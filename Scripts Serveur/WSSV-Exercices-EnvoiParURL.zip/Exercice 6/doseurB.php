<!DOCTYPE html>
<html>

<head>
    <title>EX6.B Doseur.php</title>
    <meta charset="UTF-8">
</head>

<body>
    <?php
    $NbRandom = rand(0, 100); //Génère un nombre aléatoire entre 0 et 100 non compris
    if (isset($NbRandom)) {
    ?>
        <!--Affichage Liens -->
        <a href="doseurB.php?choix=preceImpair">Précédent Impair</a>
        <a href="doseurB.php?choix=ppetit">Plus petit</a>
        <?php echo $NbRandom; ?>
        <a href="doseurB.php?choix=pgrand">Plus Grand</a>
        <a href="doseurB.php?choix=prochPair">Prochain Pair</a>

    <?php
        if (isset($_GET['choix'])) {
            $choix = $_GET['choix'];

            if ($choix == 'ppetit') {
                $maxNb = $NbRandom; //Génère la borne supérieure du prochain nombre aléatoire
                $NbRandom = rand(0, $maxNb - 1);
                echo "<p>Nouveau chiffre plus petit: " . $NbRandom . "</p>";
            } elseif ($choix == 'pgrand') {
                $minNb = $NbRandom; //Génère la borne inférieure du prochain nombre aléatoire
                $NbRandom = rand($minNb + 1, 100);
                echo "<p>Nouveau chiffre plus grand: " . $NbRandom . "</p>";
            } elseif ($choix == "preceImpair") {
                if ($NbRandom % 2 == 0) { //Si le nombre aléatoire est pair
                    $NbImpair = $NbRandom - 1;
                } else {
                    $NbImpair = $NbRandom - 2;
                }
                echo "<p>Chiffe Impair Précédent:" . $NbImpair . "</p>";
            } elseif ($choix == "prochPair") { //Si le nombre aléatoire est impair
                if ($NbRandom % 2 == 1) {
                    $NbPair = $NbRandom + 1;
                } else {
                    $NbPair = $NbRandom + 2;
                }
                echo "<p>Prochain Chiffre Pair:" . $NbPair . "</p>";
            }
        }
    } ?>

</body>

</html>