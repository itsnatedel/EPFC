<!DOCTYPE html>
<html>

<head>
    <title>EX6.A Doseur.php</title>
    <meta charset="UTF-8">
</head>

<body>
    <?php
    $NbRandom = rand(0, 100); //Génère un nombre aléatoire entre 0 et 100 non compris
    if (isset($NbRandom)) {
    ?>
        <!-- Affichage des liens -->
        <a href="doseurA.php?choix=ppetit">Plus petit</a>
        <?php echo $NbRandom; ?>
        <a href="doseurA.php?choix=pgrand">Plus Grand</a>
    <?php
        if (isset($_GET['choix'])) {
            $choix = $_GET['choix'];
            if ($choix == 'ppetit') {
                $maxNb = $NbRandom; //Génère la borne supérieure du prochain nombre aléatoire
                $NbRandom = rand(0, $maxNb - 1);
                echo "<p>Nouveau chiffre plus petit: " . $NbRandom . "</p>";
            } elseif ($choix == 'pgrand') {
                $minNb = $NbRandom; //Génère la borne inférieure du prochain nombre aléatoire
                $NbRandom = rand($minNb + 1, 100);
                echo "<p>Nouveau chiffre plus grand: " . $NbRandom . "</p>";
            }
        }
    } ?>

</body>

</html>