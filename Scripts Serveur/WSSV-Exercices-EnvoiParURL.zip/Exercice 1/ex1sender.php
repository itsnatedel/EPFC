<!DOCTYPE html>
<html>

<head>
    <title>Ex1 Sender</title>
    <meta charset="UTF-8">
</head>

<body>
    <form action="ex1receiver.php" method="get">
        <input type="text" name="message" placeholder="Entrez votre message..." />
        <input type="submit" name="btSend" value="Envoyer" />
    </form>
</body>

</html>