<?php 
    $message = !empty($_GET['message']) ? $_GET['message'] : "Aucun message";
    echo $message;
?>