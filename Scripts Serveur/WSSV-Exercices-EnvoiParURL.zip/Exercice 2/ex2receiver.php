<meta charset="UTF-8">
<?php
    if(isset($_GET['message']) && !empty($_GET['message'])) {
        echo "<p>Message re&ccedil;u</p>";
        $message = $_GET['message'];
        if($message == "Message Hyperlien") {
            echo "<p>Message venant du lien!</p>";
        } else {
            echo "Message venant du formulaire!<br/>";
        }
        
        echo "<p>Le message est: " . $message . "</p>";

        if(isset($_GET['scriptName'])) {
            $script = $_GET['scriptName'];
            echo "<p>Le script: " . $script . "</p>";
        }

    } else {
        echo "<p>Message non re&ccedil;u</p>";
    }

?>
