<!DOCTYPE html>
<html>
    
    <head>
        <title>Ex2Sender</title>
        <meta charset="UTF-8">
    </head>

    <body>
        <a href="ex2receiver.php?message=Message Hyperlien&scriptName=ex2sender.php">Message Hyperlien!</a>

        <form action="ex2receiver.php" method="GET">
            <input type="text" name="message" />
            <input type="submit" value="Envoyer" name="btSend" />
            <input type="hidden" name="scriptName" value="ex2sender.php" />
        </form>

    </body>

</html>